	var form = document.querySelector("form")

form.addEventListener("submit",(e)=>{
    e.preventDefault()

    var username = form.username.value
    var password = form.password.value

    var authenticated = authentication(username,password)

    if(authenticated){
        window.location.href = "logout.html"
    }else{"alert('wrong')"}
})

// function for checking username and password

function authentication(username,password){
    if(username === "admin" && password === "password"){
        return true
    }else{
        return false
    }
}