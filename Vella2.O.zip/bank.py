a=input(int("Enter a Value:"));
print(a);